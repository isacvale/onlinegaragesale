export default [
  {
    type: 'CDs',
    name: 'Elvis Presley',
    short: 'A nice CD from the King.',
    long: 'A very nice CD from the King.',
    images: ['cd-elvis-01.jpg'],
    price: 3,
    status: null
  },
  {
    type: 'Video-game',
    name: 'Wii U',
    short: 'A googy goody Netflix player.',
    long: 'It could play games occasionally.',
    images: ['videogame-wiiu-01.jpeg'],
    price: 55,
    status: null
  }
]